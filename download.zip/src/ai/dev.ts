import { config } from 'dotenv';
config();

import '@/ai/flows/generate-avatar.ts';
import '@/ai/flows/add-humorous-accessories.ts';