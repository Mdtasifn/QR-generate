import { TicTacToe } from '@/components/tic-tac-toe';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 bg-background">
      <div className="w-full max-w-md mx-auto">
        <header className="text-center mb-8">
          <h1 className="font-headline text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-foreground">
            Tic Tac Toe
          </h1>
          <p className="mt-3 text-lg text-muted-foreground font-body max-w-md mx-auto">
            Play a classic game of X's and O's.
          </p>
        </header>
        <TicTacToe />
      </div>
    </main>
  );
}
