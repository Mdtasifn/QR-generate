import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import MainLayout from '@/components/layout/MainLayout';
import HomePage from '@/pages/HomePage';
import GamePage from '@/pages/GamePage';
import QrCodePage from '@/pages/QrCodePage';

function App() {
  return (
    <>
      <Helmet>
        <title>Recipe, Game & QR Zone</title>
        <meta name="description" content="Generate recipes, play a fun game, or create QR codes!" />
      </Helmet>
      
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<HomePage />} />
          <Route path="game" element={<GamePage />} />
          <Route path="qrcode" element={<QrCodePage />} />
        </Route>
      </Routes>
      
      <Toaster />
    </>
  );
}

export default App;