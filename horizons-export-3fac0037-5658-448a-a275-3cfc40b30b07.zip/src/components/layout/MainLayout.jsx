import React from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChefHat, Gamepad2, QrCode } from 'lucide-react';

const MainLayout = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Recipe Maker', icon: <ChefHat className="w-5 h-5" /> },
    { path: '/game', label: 'Fun Game', icon: <Gamepad2 className="w-5 h-5" /> },
    { path: '/qrcode', label: 'QR Generator', icon: <QrCode className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <nav className="p-4 flex justify-center">
        <div className="flex space-x-2 bg-green-900/30 backdrop-blur-sm p-2 rounded-full border border-green-500/30">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className="relative px-4 py-2 text-sm font-medium text-green-200 hover:text-white transition-colors duration-300"
            >
              <span className="relative z-10 flex items-center gap-2">
                {item.icon}
                {item.label}
              </span>
              {location.pathname === item.path && (
                <motion.div
                  layoutId="active-nav-item"
                  className="absolute inset-0 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              )}
            </NavLink>
          ))}
        </div>
      </nav>
      <main className="flex-grow">
        <Outlet />
      </main>
    </div>
  );
};

export default MainLayout;