import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import QRCode from 'qrcode.react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Link, Text } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const QrCodeGenerator = () => {
  const [inputValue, setInputValue] = useState('');
  const [qrValue, setQrValue] = useState('');
  const qrRef = useRef(null);
  const { toast } = useToast();

  const handleGenerate = () => {
    if (!inputValue.trim()) {
      toast({
        title: 'Input is empty!',
        description: 'Please enter some text or a URL to generate a QR code.',
        variant: 'destructive',
      });
      return;
    }
    setQrValue(inputValue);
    toast({
      title: 'QR Code Generated!',
      description: 'Your QR code is ready to be shared.',
    });
  };

  const handleDownload = () => {
    if (!qrValue || !qrRef.current) return;
    const canvas = qrRef.current.querySelector('canvas');
    if (canvas) {
      const pngUrl = canvas
        .toDataURL('image/png')
        .replace('image/png', 'image/octet-stream');
      let downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = 'qrcode.png';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      toast({
        title: 'Download Started!',
        description: 'Your QR code is being downloaded.',
      });
    }
  };

  return (
    <div className="container mx-auto p-4 flex flex-col items-center">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-400 via-emerald-400 to-lime-400 bg-clip-text text-transparent">
          Instant QR Code Generator
        </h1>
        <p className="text-lg text-green-200 mt-2">
          Turn any text or link into a scannable QR code in seconds.
        </p>
      </motion.div>

      <Card className="w-full max-w-md recipe-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl text-white">
            <Link className="w-6 h-6" />
            Enter Your Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Enter URL or text..."
              className="bg-green-900/30 border-green-500/50 text-white placeholder:text-green-300/70"
            />
            <Button onClick={handleGenerate} className="bg-green-500 hover:bg-green-600">
              Generate
            </Button>
          </div>
        </CardContent>
      </Card>

      <AnimatePresence>
        {qrValue && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="mt-8 flex flex-col items-center"
          >
            <div ref={qrRef} className="p-4 bg-white rounded-lg shadow-lg">
              <QRCode
                value={qrValue}
                size={256}
                level={'H'}
                includeMargin={true}
              />
            </div>
            <Button onClick={handleDownload} className="mt-4 bg-emerald-500 hover:bg-emerald-600">
              <Download className="mr-2 h-4 w-4" />
              Download PNG
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default QrCodeGenerator;