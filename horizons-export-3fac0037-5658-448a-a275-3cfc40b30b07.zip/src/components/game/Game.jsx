import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import TomatoCharacter from '@/components/TomatoCharacter';
import BananaCharacter from '@/components/game/BananaCharacter';
import Bomb from '@/components/game/Bomb';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Heart, Star, Trophy, Bomb as BombIcon } from 'lucide-react';

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const PLAYER_WIDTH = 64;
const INITIAL_LIVES = 5;

const Game = () => {
  const [playerX, setPlayerX] = useState(GAME_WIDTH / 2 - PLAYER_WIDTH / 2);
  const [items, setItems] = useState([]);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(INITIAL_LIVES);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('bananaChaseHighScore') || '0', 10);
  });
  const [gameOver, setGameOver] = useState(true);
  const [gameStarted, setGameStarted] = useState(false);
  const [playerMood, setPlayerMood] = useState('happy');
  const [particles, setParticles] = useState([]);
  const gameAreaRef = useRef(null);
  const { toast } = useToast();
  const requestRef = useRef();

  const createParticles = (x, y, isBomb = false) => {
    const color = isBomb ? '#4b5563' : '#FFD700';
    const newParticles = Array.from({ length: isBomb ? 20 : 10 }).map(() => ({
      id: Math.random(),
      x,
      y,
      vx: (Math.random() - 0.5) * (isBomb ? 10 : 5),
      vy: (Math.random() - 0.5) * (isBomb ? 10 : 5),
      opacity: 1,
      color: isBomb ? `hsl(${Math.random() * 60}, 100%, 50%)` : color,
    }));
    setParticles(prev => [...prev, ...newParticles]);
  };

  const startGame = () => {
    setScore(0);
    setItems([]);
    setLives(INITIAL_LIVES);
    setGameOver(false);
    setGameStarted(true);
    setPlayerX(GAME_WIDTH / 2 - PLAYER_WIDTH / 2);
    setPlayerMood('happy');
  };

  const handleMouseMove = (e) => {
    if (gameOver || !gameAreaRef.current) return;
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const newX = e.clientX - gameArea.left - PLAYER_WIDTH / 2;
    setPlayerX(Math.max(0, Math.min(newX, GAME_WIDTH - PLAYER_WIDTH)));
  };

  const handleTouchMove = (e) => {
    if (gameOver || !gameAreaRef.current) return;
    const gameArea = gameAreaRef.current.getBoundingClientRect();
    const newX = e.touches[0].clientX - gameArea.left - PLAYER_WIDTH / 2;
    setPlayerX(Math.max(0, Math.min(newX, GAME_WIDTH - PLAYER_WIDTH)));
  };

  const gameLoop = useCallback(() => {
    if (gameOver) return;

    const fallSpeed = 2.5 + Math.floor(score / 100);

    setItems((prev) =>
      prev
        .map((item) => ({ ...item, y: item.y + (item.type === 'bomb' ? fallSpeed * 1.2 : fallSpeed) }))
        .filter((item) => {
          if (item.y > GAME_HEIGHT - 64 && item.x > playerX - 32 && item.x < playerX + PLAYER_WIDTH - 32) {
            if (item.type === 'bomb') {
              setLives((l) => l - 1);
              setPlayerMood('hurt');
              createParticles(item.x, item.y, true);
              setTimeout(() => setPlayerMood('happy'), 500);
            } else {
              const points = item.isGolden ? 50 : 10;
              setScore((s) => s + points);
              createParticles(item.x, item.y);
              setPlayerMood('excited');
              setTimeout(() => setPlayerMood('happy'), 200);
            }
            return false;
          }
          return item.y < GAME_HEIGHT;
        })
    );

    setParticles(prev => prev.map(p => ({
      ...p,
      x: p.x + p.vx,
      y: p.y + p.vy,
      opacity: p.opacity - 0.02
    })).filter(p => p.opacity > 0));

    requestRef.current = requestAnimationFrame(gameLoop);
  }, [gameOver, playerX, score]);

  useEffect(() => {
    if (!gameOver) {
      requestRef.current = requestAnimationFrame(gameLoop);
      return () => cancelAnimationFrame(requestRef.current);
    }
  }, [gameOver, gameLoop]);

  useEffect(() => {
    if (lives <= 0 && !gameOver) {
      setGameOver(true);
      setPlayerMood('hurt');
      if (score > highScore) {
        setHighScore(score);
        localStorage.setItem('bananaChaseHighScore', score.toString());
        toast({
          title: "New High Score! 🏆",
          description: `You set a new record: ${score} points!`,
        });
      }
    }
  }, [lives, gameOver, score, highScore, toast]);

  useEffect(() => {
    if (gameOver) return;

    const spawnInterval = 1000 - Math.floor(score / 50) * 50;
    const spawnItem = () => {
      const itemType = Math.random() > 0.2 ? 'banana' : 'bomb'; // 20% chance for a bomb
      
      if (itemType === 'banana') {
        const isGolden = Math.random() < 0.1;
        setItems((prev) => [
          ...prev,
          { id: Date.now(), x: Math.random() * (GAME_WIDTH - 32), y: -64, type: 'banana', isGolden },
        ]);
      } else {
        setItems((prev) => [
          ...prev,
          { id: Date.now(), x: Math.random() * (GAME_WIDTH - 32), y: -64, type: 'bomb' },
        ]);
      }
    };

    const interval = setInterval(spawnItem, Math.max(spawnInterval, 350));
    return () => clearInterval(interval);
  }, [gameOver, score]);

  return (
    <div className="flex flex-col items-center p-4 space-y-4">
      <motion.div initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} className="text-center">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-400 bg-clip-text text-transparent">
          Tomato & Banana Chase
        </h1>
        <p className="text-lg text-green-200 mt-2">Catch Bananas, Dodge Bombs! 🍌💣</p>
      </motion.div>

      <Card className="game-area relative overflow-hidden w-full max-w-[800px] aspect-[4/3]" style={{ height: GAME_HEIGHT }} ref={gameAreaRef} onMouseMove={handleMouseMove} onTouchMove={handleTouchMove}>
        <CardContent className="p-0 h-full w-full cursor-none">
          <AnimatePresence>
            {(gameOver || !gameStarted) && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-10 text-center"
              >
                {gameStarted ? (
                  <>
                    <h2 className="text-6xl font-bold text-red-500 mb-4">Game Over</h2>
                    <p className="text-2xl text-white">Your Score: <span className="font-bold text-yellow-400">{score}</span></p>
                    <p className="text-xl text-white mb-6">High Score: <span className="font-bold text-yellow-400">{highScore}</span></p>
                  </>
                ) : (
                  <>
                     <div className="flex items-end gap-4">
                      <TomatoCharacter mood="excited" size="large" />
                      <BananaCharacter size="large" />
                      <div className="self-center"><Bomb size="medium" /></div>
                    </div>
                    <h2 className="text-4xl font-bold text-white my-4">Ready to Play?</h2>
                  </>
                )}
                <Button onClick={startGame} size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold text-lg px-8 py-6 mt-4">
                  {gameStarted ? 'Play Again' : 'Start Game'}
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {!gameOver && gameStarted && (
            <>
              <motion.div className="absolute" style={{ bottom: 10, width: PLAYER_WIDTH, height: 64 }} animate={{ x: playerX }} transition={{ type: 'spring', stiffness: 500, damping: 30 }}>
                <TomatoCharacter mood={playerMood} size="small" />
              </motion.div>

              {items.map((item) => (
                <motion.div key={item.id} className="absolute" style={{ x: item.x, y: item.y }}>
                  {item.type === 'bomb' ? <Bomb size="small" /> : <BananaCharacter size="small" isGolden={item.isGolden} />}
                </motion.div>
              ))}

              {particles.map(p => (
                <motion.div
                  key={p.id}
                  className="particle"
                  initial={{ x: p.x, y: p.y, opacity: 1, scale: 1 }}
                  animate={{ x: p.x + p.vx, y: p.y + p.vy, opacity: 0, scale: 0 }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  style={{ width: 10, height: 10, background: p.color }}
                />
              ))}
            </>
          )}
        </CardContent>
      </Card>

      <div className="w-full max-w-[800px] flex justify-between items-center text-2xl font-bold text-white bg-green-800/50 px-6 py-3 rounded-lg">
        <div className="flex items-center gap-2">
          <Star className="text-yellow-400" />
          Score: <span className="text-yellow-400 w-20 text-left">{score}</span>
        </div>
        <div className="flex items-center gap-2">
          <Trophy className="text-amber-400" />
          High Score: <span className="text-amber-400">{highScore}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="mr-2">Lives:</span>
          {Array.from({ length: INITIAL_LIVES }).map((_, i) => (
            <Heart key={i} className={`transition-all duration-300 ${i < lives ? 'text-red-500 fill-current' : 'text-gray-500'}`} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Game;