import React from 'react';
import { motion } from 'framer-motion';
import { Bomb as BombIcon } from 'lucide-react';

const Bomb = ({ size = 'small' }) => {
  const sizeClasses = {
    small: 'w-10 h-10',
    medium: 'w-16 h-16',
    large: 'w-24 h-24',
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} relative flex items-center justify-center`}
      animate={{ rotate: [0, 5, -5, 0] }}
      transition={{
        repeat: Infinity,
        duration: 0.5,
        ease: 'easeInOut',
      }}
    >
      <div className="absolute w-full h-full bg-gray-800 rounded-full flex items-center justify-center shadow-lg">
        <BombIcon className="w-3/4 h-3/4 text-gray-400" />
      </div>
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-gray-600 rounded-sm"></div>
       <motion.div
        className="absolute top-[-8px] left-[calc(50%+2px)] w-1 h-3 bg-orange-500 rounded-t-full"
        animate={{ scaleY: [1, 1.5, 1], opacity: [0.8, 1, 0.8] }}
        transition={{ repeat: Infinity, duration: 1 }}
       />
    </motion.div>
  );
};

export default Bomb;