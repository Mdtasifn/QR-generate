import React from 'react';
import { motion } from 'framer-motion';

const BananaCharacter = ({ size = 'medium', isGolden = false }) => {
  const sizeClasses = {
    small: 'w-16 h-16',
    medium: 'w-24 h-24',
    large: 'w-32 h-32',
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} relative`}
      initial={{ rotate: -15 }}
      animate={{ rotate: 15 }}
      transition={{
        repeat: Infinity,
        repeatType: 'reverse',
        duration: 1.5,
        ease: 'easeInOut',
      }}
    >
      <svg viewBox="0 0 60 60" className="w-full h-full drop-shadow-lg">
        {isGolden && (
          <defs>
            <radialGradient id="goldenGradient">
              <stop offset="0%" stopColor="#FFF7B2" />
              <stop offset="50%" stopColor="#FFD700" />
              <stop offset="100%" stopColor="#FDB813" />
            </radialGradient>
          </defs>
        )}
        <motion.path
          d="M 20 45 C 10 30, 30 10, 45 20 C 40 35, 35 45, 20 45 Z"
          fill={isGolden ? "url(#goldenGradient)" : "#FFD700"}
          stroke={isGolden ? "#FDB813" : "#DAA520"}
          strokeWidth="2"
        />
        <path d="M 45 20 L 48 15" stroke="#6B4226" strokeWidth="3" strokeLinecap="round" />
        
        <circle cx="30" cy="28" r="2" fill="black" />
        <circle cx="38" cy="25" r="2" fill="black" />
        
        <path d="M 32 35 Q 35 38 38 35" stroke="black" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        
        {isGolden && (
          <motion.g
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <path d="M 30 20 L 32 18 L 34 20 L 32 22 Z" fill="white" opacity="0.8" />
            <path d="M 25 30 L 27 28 L 29 30 L 27 32 Z" fill="white" opacity="0.6" />
          </motion.g>
        )}
      </svg>
    </motion.div>
  );
};

export default BananaCharacter;