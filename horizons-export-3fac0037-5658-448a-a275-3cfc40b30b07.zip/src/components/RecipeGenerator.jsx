
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Plus, X, ChefHat, Clock, Users } from 'lucide-react';
import TomatoCharacter from '@/components/TomatoCharacter';

const RecipeGenerator = () => {
  const [ingredients, setIngredients] = useState([]);
  const [currentIngredient, setCurrentIngredient] = useState('');
  const [generatedRecipe, setGeneratedRecipe] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  // Sample recipes database
  const recipeDatabase = [
    {
      name: "Spicy Tomato Pasta",
      ingredients: ["tomato", "pasta", "garlic", "onion"],
      cookTime: "20 mins",
      servings: 4,
      difficulty: "Easy",
      instructions: [
        "Boil pasta according to package directions",
        "Sauté garlic and onion until fragrant",
        "Add diced tomatoes and simmer for 10 minutes",
        "Toss with cooked pasta and serve hot"
      ]
    },
    {
      name: "Fresh Garden Salad",
      ingredients: ["lettuce", "tomato", "cucumber", "carrot"],
      cookTime: "10 mins",
      servings: 2,
      difficulty: "Easy",
      instructions: [
        "Wash and chop all vegetables",
        "Mix in a large bowl",
        "Add your favorite dressing",
        "Serve immediately"
      ]
    },
    {
      name: "Vegetable Stir Fry",
      ingredients: ["carrot", "broccoli", "onion", "garlic"],
      cookTime: "15 mins",
      servings: 3,
      difficulty: "Medium",
      instructions: [
        "Heat oil in a large pan",
        "Add garlic and onion, cook for 2 minutes",
        "Add harder vegetables first, then softer ones",
        "Stir fry for 8-10 minutes until tender-crisp"
      ]
    },
    {
      name: "Creamy Mushroom Soup",
      ingredients: ["mushroom", "onion", "garlic", "cream"],
      cookTime: "25 mins",
      servings: 4,
      difficulty: "Medium",
      instructions: [
        "Sauté mushrooms until golden",
        "Add onion and garlic, cook until soft",
        "Add broth and simmer for 15 minutes",
        "Stir in cream and season to taste"
      ]
    }
  ];

  const addIngredient = () => {
    if (currentIngredient.trim() && !ingredients.includes(currentIngredient.trim().toLowerCase())) {
      setIngredients([...ingredients, currentIngredient.trim().toLowerCase()]);
      setCurrentIngredient('');
      toast({
        title: "Ingredient added! 🥕",
        description: `${currentIngredient} has been added to your fridge.`,
      });
    }
  };

  const removeIngredient = (ingredient) => {
    setIngredients(ingredients.filter(item => item !== ingredient));
  };

  const generateRecipe = () => {
    if (ingredients.length === 0) {
      toast({
        title: "Oops! 🍅",
        description: "Please add some ingredients first!",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    
    // Simulate API call delay
    setTimeout(() => {
      // Find recipes that match available ingredients
      const matchingRecipes = recipeDatabase.filter(recipe => 
        recipe.ingredients.some(ingredient => 
          ingredients.includes(ingredient.toLowerCase())
        )
      );

      if (matchingRecipes.length > 0) {
        // Pick the recipe with most matching ingredients
        const bestMatch = matchingRecipes.reduce((best, current) => {
          const currentMatches = current.ingredients.filter(ingredient => 
            ingredients.includes(ingredient.toLowerCase())
          ).length;
          const bestMatches = best.ingredients.filter(ingredient => 
            ingredients.includes(ingredient.toLowerCase())
          ).length;
          
          return currentMatches > bestMatches ? current : best;
        });

        setGeneratedRecipe(bestMatch);
        toast({
          title: "Recipe ready! 👨‍🍳",
          description: `I found the perfect recipe for you: ${bestMatch.name}`,
        });
      } else {
        // Generate a creative recipe suggestion
        const creativeSuggestion = {
          name: `Creative ${ingredients[0].charAt(0).toUpperCase() + ingredients[0].slice(1)} Delight`,
          ingredients: ingredients,
          cookTime: "15-20 mins",
          servings: 2,
          difficulty: "Easy",
          instructions: [
            `Start by preparing your ${ingredients.join(', ')}`,
            "Get creative with seasoning - salt, pepper, and herbs work great!",
            "Cook using your preferred method - sauté, roast, or steam",
            "Combine everything and adjust seasoning to taste",
            "Serve hot and enjoy your unique creation!"
          ]
        };
        
        setGeneratedRecipe(creativeSuggestion);
        toast({
          title: "Creative recipe generated! 🎨",
          description: "I created a unique recipe just for your ingredients!",
        });
      }
      
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen p-4 space-y-8">
      {/* Header with Tomato Character */}
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <TomatoCharacter mood={generatedRecipe ? 'cooking' : 'happy'} size="large" />
        <div>
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            Recipe Maker
          </h1>
          <p className="text-lg text-green-200 mt-2">
            Tell me what's in your fridge, and I'll create magic! 🍅✨
          </p>
        </div>
      </motion.div>

      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Ingredients Section */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="ingredient-card border-green-500/30 bg-green-900/20">
            <CardHeader>
              <CardTitle className="text-green-300 flex items-center gap-2">
                <ChefHat className="w-6 h-6" />
                Your Fridge Ingredients
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add an ingredient..."
                  value={currentIngredient}
                  onChange={(e) => setCurrentIngredient(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addIngredient()}
                  className="bg-green-800/30 border-green-600/50 text-white placeholder-green-300"
                />
                <Button
                  onClick={addIngredient}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <AnimatePresence>
                  {ingredients.map((ingredient, index) => (
                    <motion.div
                      key={ingredient}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0 }}
                      className="bg-green-600/80 text-white px-3 py-1 rounded-full flex items-center gap-2 text-sm"
                    >
                      {ingredient}
                      <button
                        onClick={() => removeIngredient(ingredient)}
                        className="hover:bg-green-700 rounded-full p-1"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <Button
                onClick={generateRecipe}
                disabled={isGenerating || ingredients.length === 0}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-semibold py-3"
              >
                {isGenerating ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                  />
                ) : (
                  "Generate Recipe! 🍳"
                )}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recipe Display Section */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <AnimatePresence mode="wait">
            {generatedRecipe ? (
              <motion.div
                key="recipe"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -50 }}
              >
                <Card className="recipe-card border-green-400/40 bg-green-800/20">
                  <CardHeader>
                    <CardTitle className="text-green-300 flex items-center justify-between">
                      <span>{generatedRecipe.name}</span>
                      <TomatoCharacter mood="excited" size="small" />
                    </CardTitle>
                    <div className="flex gap-4 text-sm text-green-200">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {generatedRecipe.cookTime}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {generatedRecipe.servings} servings
                      </div>
                      <div className="px-2 py-1 bg-green-600/50 rounded text-xs">
                        {generatedRecipe.difficulty}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-green-300 mb-2">Ingredients:</h3>
                      <div className="flex flex-wrap gap-2">
                        {generatedRecipe.ingredients.map((ingredient, index) => (
                          <span
                            key={index}
                            className={`px-2 py-1 rounded text-xs ${
                              ingredients.includes(ingredient.toLowerCase())
                                ? 'bg-green-600/80 text-white'
                                : 'bg-yellow-600/80 text-white'
                            }`}
                          >
                            {ingredient}
                            {!ingredients.includes(ingredient.toLowerCase()) && ' (need to buy)'}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold text-green-300 mb-2">Instructions:</h3>
                      <ol className="space-y-2">
                        {generatedRecipe.instructions.map((step, index) => (
                          <motion.li
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex gap-3 text-green-100"
                          >
                            <span className="bg-green-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold flex-shrink-0">
                              {index + 1}
                            </span>
                            {step}
                          </motion.li>
                        ))}
                      </ol>
                    </div>

                    <Button
                      onClick={() => setGeneratedRecipe(null)}
                      variant="outline"
                      className="w-full border-green-500 text-green-300 hover:bg-green-600/20"
                    >
                      Generate Another Recipe
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex items-center justify-center"
              >
                <Card className="ingredient-card border-green-500/20 bg-green-900/10">
                  <CardContent className="p-8 text-center space-y-4">
                    <TomatoCharacter mood="thinking" size="medium" />
                    <div className="text-green-200">
                      <h3 className="text-xl font-semibold mb-2">Ready to Cook?</h3>
                      <p>Add your ingredients and I'll suggest the perfect recipe for you!</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default RecipeGenerator;
