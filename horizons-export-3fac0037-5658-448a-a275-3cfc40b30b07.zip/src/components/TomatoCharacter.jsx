import React from 'react';
import { motion } from 'framer-motion';

const TomatoCharacter = ({ mood = 'happy', size = 'large' }) => {
  const sizeClasses = {
    small: 'w-16 h-16',
    medium: 'w-24 h-24',
    large: 'w-32 h-32'
  };

  const expressions = {
    happy: {
      mouth: 'M 20 25 Q 30 35 40 25',
      color: '#ef4444'
    },
    excited: {
      mouth: 'M 18 25 Q 30 40 42 25',
      color: '#dc2626'
    },
    thinking: {
      mouth: 'M 25 30 Q 30 32 35 30',
      color: '#f87171'
    },
    cooking: {
      mouth: 'M 20 28 Q 30 35 40 28',
      color: '#ef4444'
    },
    sad: {
      mouth: 'M 20 35 Q 30 25 40 35',
      color: '#f87171'
    },
    hurt: {
      mouth: 'M 22 32 L 38 32',
      color: '#b91c1c'
    }
  };

  const currentExpression = expressions[mood] || expressions.happy;

  return (
    <motion.div
      className={`${sizeClasses[size]} relative ${mood !== 'hurt' ? 'tomato-bounce' : ''}`}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    >
      <svg
        viewBox="0 0 60 60"
        className="w-full h-full drop-shadow-lg"
      >
        <motion.circle
          cx="30"
          cy="35"
          r="20"
          fill={currentExpression.color}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
        />
        
        <motion.path
          d="M 25 15 Q 30 10 35 15 Q 32 12 30 15 Q 28 12 25 15"
          fill="#22c55e"
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        />
        
        {mood === 'hurt' ? (
          <>
            <motion.path d="M 22 28 L 28 34" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <motion.path d="M 28 28 L 22 34" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <motion.path d="M 32 28 L 38 34" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <motion.path d="M 38 28 L 32 34" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </>
        ) : (
          <>
            <motion.circle cx="25" cy="30" r="3" fill="white" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6 }} />
            <motion.circle cx="35" cy="30" r="3" fill="white" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6 }} />
            <motion.circle cx="25" cy="30" r="1.5" fill="black" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.8 }} />
            <motion.circle cx="35" cy="30" r="1.5" fill="black" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.8 }} />
          </>
        )}
        
        <motion.path
          d={currentExpression.mouth}
          stroke="white"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
        />
        
        <motion.circle cx="18" cy="35" r="2" fill="#fca5a5" opacity="0.6" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1.2 }} />
        <motion.circle cx="42" cy="35" r="2" fill="#fca5a5" opacity="0.6" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1.2 }} />
      </svg>
      
      {mood === 'cooking' && (
        <motion.div
          className="absolute -top-4 left-1/2 transform -translate-x-1/2"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <div className="w-8 h-6 bg-white rounded-t-full border-2 border-gray-200"></div>
          <div className="w-12 h-2 bg-white border-2 border-gray-200 border-t-0 rounded-b-sm"></div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default TomatoCharacter;