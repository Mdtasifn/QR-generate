import React from 'react';
import { Helmet } from 'react-helmet';
import QrCodeGenerator from '@/components/qrcode/QrCodeGenerator';

const QrCodePage = () => {
  return (
    <>
      <Helmet>
        <title>QR Code Generator</title>
        <meta name="description" content="Generate a QR code from any text or URL instantly." />
      </Helmet>
      <QrCodeGenerator />
    </>
  );
};

export default QrCodePage;