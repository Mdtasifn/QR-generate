
import React from 'react';
import RecipeGenerator from '@/components/RecipeGenerator';

const HomePage = () => {
  return <RecipeGenerator />;
};

export default HomePage;
