
import React from 'react';
import { Helmet } from 'react-helmet';
import Game from '@/components/game/Game';

const GamePage = () => {
  return (
    <>
      <Helmet>
        <title>Fun Game - Catch the Bananas!</title>
        <meta name="description" content="Play a fun game where you control a tomato character to catch falling bananas. How high can you score?" />
      </Helmet>
      <Game />
    </>
  );
};

export default GamePage;
